package generic;

public class Statistics {

	public static void printStatistics(String statFile)
	{
		
	}
}
