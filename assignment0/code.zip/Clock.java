public class Clock {
    int time;

    public Clock(){
        time=0;
    }

    public void incrimentTime(int incriment) {
        time += incriment;
    }
}