package processor.pipeline.latch;

public class EX_IF_LatchType {
	
	public EX_IF_LatchType()
	{
		
	}

}
